Thanks for downloading this theme!

Theme Name: KnightOne
Theme URL: https://bootstrapmade.com/knight-simple-one-page-bootstrap-template/
Author: BootstrapMade
Author URL: https://bootstrapmade.com